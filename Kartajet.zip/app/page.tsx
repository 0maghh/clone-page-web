import Image from "next/image"
import Link from "next/link"
import { Globe, Menu, Search, ShoppingCart, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-[#FDF6E3]">
      {/* Top Bar */}
      <div className="hidden border-b border-[#6A0DAD]/20 bg-[#FDF6E3] py-1 md:block">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="#" className="text-xs text-[#1C1C1C] hover:text-[#6A0DAD]">
              Kartajet Business
            </Link>
            <Link href="#" className="text-xs text-[#1C1C1C] hover:text-[#6A0DAD]">
              About Us
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Globe className="h-3 w-3 text-[#6A0DAD]" />
              <span className="text-xs">FR</span>
            </div>
            <Link href="#" className="text-xs text-[#1C1C1C] hover:text-[#6A0DAD]">
              Careers
            </Link>
            <Link href="#" className="text-xs text-[#1C1C1C] hover:text-[#6A0DAD]">
              Contact Us
            </Link>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header className="sticky top-0 z-50 border-b border-[#6A0DAD]/20 bg-[#FDF6E3]">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-[#6A0DAD] md:hidden">
              <Menu className="h-6 w-6" />
            </Button>
            <Link href="/" className="flex items-center gap-2">
              <div className="relative h-10 w-32 overflow-hidden rounded bg-[#1C0033]">
                <Image
                  src="/images/kartajet-logo.png"
                  alt="Kartajet Logo"
                  width={120}
                  height={40}
                  className="h-full w-full object-contain"
                  priority
                />
              </div>
            </Link>
          </div>

          <nav className="hidden md:flex md:items-center md:gap-6">
            <Link href="#" className="text-sm font-medium text-[#1C1C1C] hover:text-[#6A0DAD]">
              Services
            </Link>
            <Link href="#" className="text-sm font-medium text-[#1C1C1C] hover:text-[#6A0DAD]">
              Support
            </Link>
            <Link href="#" className="text-sm font-medium text-[#1C1C1C] hover:text-[#6A0DAD]">
              For Businesses
            </Link>
            <Link href="#" className="text-sm font-medium text-[#1C1C1C] hover:text-[#6A0DAD]">
              Offers
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-[#6A0DAD]">
              <Search className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-[#6A0DAD]">
              <ShoppingCart className="h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="hidden gap-2 border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#6A0DAD] hover:text-white md:flex"
            >
              <User className="h-4 w-4" />
              <span>Login</span>
            </Button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="relative">
          <div className="relative h-[400px] w-full md:h-[600px] lg:h-[700px]">
            <Image
              src="/images/kartajet-hero.png"
              alt="Kartajet 5G - Tunisia rises, Tunisia is stronger"
              fill
              className="object-cover object-center"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1C0033]/40 to-transparent">
              <div className="container relative h-full">
                {/* CTA Button positioned at bottom right */}
                <div className="absolute bottom-8 right-4 md:bottom-12 md:right-8">
                  <Button className="bg-[#FFD700] text-[#1C0033] hover:bg-[#FFD700]/90 border border-[#FFD700]/20 shadow-lg font-serif tracking-wide text-base md:text-lg px-6 py-6 md:py-7 rounded-md transition-all duration-300 hover:scale-105">
                    Découvrez Kartajet
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-12">
          <div className="container">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <div className="flex flex-col items-center rounded-lg bg-white p-6 shadow-md transition-all hover:shadow-lg">
                <div className="mb-4 rounded-full bg-[#6A0DAD]/10 p-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#6A0DAD]"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                </div>
                <h3 className="text-center font-medium">Mobile Plans</h3>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-white p-6 shadow-md transition-all hover:shadow-lg">
                <div className="mb-4 rounded-full bg-[#6A0DAD]/10 p-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#6A0DAD]"
                  >
                    <rect width="20" height="14" x="2" y="5" rx="2" />
                    <line x1="2" x2="22" y1="10" y2="10" />
                  </svg>
                </div>
                <h3 className="text-center font-medium">Recharge</h3>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-white p-6 shadow-md transition-all hover:shadow-lg">
                <div className="mb-4 rounded-full bg-[#6A0DAD]/10 p-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#6A0DAD]"
                  >
                    <path d="M20 10V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v3" />
                    <path d="M20 14v3a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3" />
                    <path d="M12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
                    <path d="M12 12v4" />
                  </svg>
                </div>
                <h3 className="text-center font-medium">Internet</h3>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-white p-6 shadow-md transition-all hover:shadow-lg">
                <div className="mb-4 rounded-full bg-[#6A0DAD]/10 p-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#6A0DAD]"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="16" x2="8" y1="13" y2="13" />
                    <line x1="16" x2="8" y1="17" y2="17" />
                    <line x1="10" x2="8" y1="9" y2="9" />
                  </svg>
                </div>
                <h3 className="text-center font-medium">My Account</h3>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-12 bg-white">
          <div className="container">
            <div className="mb-10 text-center">
              <h2 className="font-serif text-3xl font-bold tracking-tight text-[#1C1C1C] md:text-4xl">
                Premium Services
              </h2>
              <p className="mt-2 text-[#1C1C1C]/70">Discover our range of exclusive services designed for your needs</p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <div className="group overflow-hidden rounded-lg border border-[#6A0DAD]/10 bg-[#FDF6E3] shadow-sm transition-all hover:shadow-md">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=200&width=400"
                    alt="Premium Internet"
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1C1C1C]/70 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <h3 className="font-serif text-xl font-bold text-white">Premium Internet</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="mb-4 text-sm text-[#1C1C1C]/70">
                    Ultra-fast fiber internet with unlimited data and priority support.
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#6A0DAD] hover:text-white"
                  >
                    Learn More
                  </Button>
                </div>
              </div>

              <div className="group overflow-hidden rounded-lg border border-[#6A0DAD]/10 bg-[#FDF6E3] shadow-sm transition-all hover:shadow-md">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=200&width=400"
                    alt="Elite Mobile Plans"
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1C1C1C]/70 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <h3 className="font-serif text-xl font-bold text-white">Elite Mobile Plans</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="mb-4 text-sm text-[#1C1C1C]/70">
                    Exclusive mobile plans with unlimited calls, data, and international roaming.
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#6A0DAD] hover:text-white"
                  >
                    Learn More
                  </Button>
                </div>
              </div>

              <div className="group overflow-hidden rounded-lg border border-[#6A0DAD]/10 bg-[#FDF6E3] shadow-sm transition-all hover:shadow-md">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=200&width=400"
                    alt="Business Solutions"
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1C1C1C]/70 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <h3 className="font-serif text-xl font-bold text-white">Business Solutions</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="mb-4 text-sm text-[#1C1C1C]/70">
                    Tailored telecommunications solutions for businesses of all sizes.
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#6A0DAD] hover:text-white"
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Promo Carousel */}
        <section className="py-12">
          <div className="container">
            <div className="mb-10 text-center">
              <h2 className="font-serif text-3xl font-bold tracking-tight text-[#1C1C1C] md:text-4xl">
                Exclusive Offers
              </h2>
              <p className="mt-2 text-[#1C1C1C]/70">Limited-time promotions and special deals</p>
            </div>

            <Carousel className="w-full">
              <CarouselContent>
                {[1, 2, 3].map((item) => (
                  <CarouselItem key={item} className="md:basis-1/2 lg:basis-1/3">
                    <div className="overflow-hidden rounded-lg bg-white p-1 shadow-md">
                      <div className="overflow-hidden rounded-lg">
                        <Image
                          src={`/placeholder.svg?height=200&width=400&text=Promo+${item}`}
                          alt={`Promo ${item}`}
                          width={400}
                          height={200}
                          className="h-48 w-full object-cover transition-transform duration-300 hover:scale-105"
                        />
                      </div>
                      <div className="p-6">
                        <div className="mb-2 inline-block rounded-full bg-[#6A0DAD]/10 px-3 py-1 text-xs font-medium text-[#6A0DAD]">
                          Limited Time
                        </div>
                        <h3 className="mb-2 font-serif text-lg font-semibold">Premium Offer {item}</h3>
                        <p className="mb-4 text-sm text-[#1C1C1C]/70">
                          Exclusive benefits and premium services at special rates.
                        </p>
                        <Button className="w-full bg-[#FFD700] text-[#1C1C1C] hover:bg-[#FFD700]/90">Get Now</Button>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <div className="flex justify-center gap-2 pt-4">
                <CarouselPrevious className="relative inset-auto translate-y-0 border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#6A0DAD] hover:text-white" />
                <CarouselNext className="relative inset-auto translate-y-0 border-[#6A0DAD] text-[#6A0DAD] hover:bg-[#6A0DAD] hover:text-white" />
              </div>
            </Carousel>
          </div>
        </section>

        {/* App Download */}
        <section className="py-12 bg-white">
          <div className="container">
            <div className="overflow-hidden rounded-xl bg-gradient-to-r from-[#6A0DAD] to-[#8A2BE2]">
              <div className="grid items-center gap-8 md:grid-cols-2">
                <div className="p-8 text-white">
                  <h2 className="mb-4 font-serif text-3xl font-bold tracking-tight md:text-4xl">
                    Download the Kartajet App
                  </h2>
                  <p className="mb-6">
                    Manage your account, pay bills, recharge, and enjoy exclusive offers all in one place.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Image
                      src="/placeholder.svg?height=50&width=150&text=App+Store"
                      alt="App Store"
                      width={150}
                      height={50}
                      className="h-12 w-auto"
                    />
                    <Image
                      src="/placeholder.svg?height=50&width=150&text=Google+Play"
                      alt="Google Play"
                      width={150}
                      height={50}
                      className="h-12 w-auto"
                    />
                  </div>
                </div>
                <div className="flex justify-center p-4">
                  <div className="relative h-[300px] w-[200px] md:h-[400px] md:w-[250px]">
                    <Image
                      src="/placeholder.svg?height=400&width=250&text=App+Screenshot"
                      alt="Kartajet App"
                      fill
                      className="object-contain"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-12">
          <div className="container">
            <div className="mb-10 text-center">
              <h2 className="font-serif text-3xl font-bold tracking-tight text-[#1C1C1C] md:text-4xl">
                What Our Clients Say
              </h2>
              <p className="mt-2 text-[#1C1C1C]/70">Hear from our satisfied customers</p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              {[1, 2, 3].map((item) => (
                <div key={item} className="rounded-lg border border-[#6A0DAD]/10 bg-white p-6 shadow-md">
                  <div className="mb-4 flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <svg
                        key={star}
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="#FFD700"
                        stroke="#FFD700"
                        strokeWidth="1"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                      </svg>
                    ))}
                  </div>
                  <p className="mb-4 italic text-[#1C1C1C]/70">
                    "Kartajet provides exceptional service with lightning-fast internet and reliable connectivity. Their
                    customer support is outstanding."
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-[#6A0DAD]/20"></div>
                    <div>
                      <h4 className="font-medium">Client Name</h4>
                      <p className="text-xs text-[#1C1C1C]/70">Premium Customer</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-auto bg-[#1C1C1C] text-white">
        <div className="container py-12">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <div className="relative mb-4 h-12 w-36 overflow-hidden rounded bg-[#1C0033]">
                <Image
                  src="/images/kartajet-logo.png"
                  alt="Kartajet Logo"
                  width={144}
                  height={48}
                  className="h-full w-full object-contain"
                />
              </div>
              <p className="mt-4 text-sm text-gray-400">
                Kartajet is Tunisia's premium telecommunications provider offering innovative solutions for individuals
                and businesses.
              </p>
              <div className="mt-4 flex gap-4">
                <Link href="#" className="rounded-full bg-[#6A0DAD]/20 p-2 text-white hover:bg-[#6A0DAD]/40">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                  </svg>
                </Link>
                <Link href="#" className="rounded-full bg-[#6A0DAD]/20 p-2 text-white hover:bg-[#6A0DAD]/40">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                  </svg>
                </Link>
                <Link href="#" className="rounded-full bg-[#6A0DAD]/20 p-2 text-white hover:bg-[#6A0DAD]/40">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                  </svg>
                </Link>
                <Link href="#" className="rounded-full bg-[#6A0DAD]/20 p-2 text-white hover:bg-[#6A0DAD]/40">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                    <rect width="4" height="12" x="2" y="9" />
                    <circle cx="4" cy="4" r="2" />
                  </svg>
                </Link>
              </div>
            </div>

            <div>
              <h3 className="mb-4 font-serif text-lg font-semibold">Services</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Mobile Plans
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Internet
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Devices
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Roaming
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Entertainment
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="mb-4 font-serif text-lg font-semibold">Support</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Store Locator
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    Coverage Map
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-gray-400 hover:text-[#FFD700]">
                    FAQs
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="mb-4 font-serif text-lg font-semibold">Contact</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm text-gray-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mt-0.5 flex-shrink-0 text-[#FFD700]"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                  <span>Customer Service: 1234</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-gray-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mt-0.5 flex-shrink-0 text-[#FFD700]"
                  >
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                    <polyline points="22,6 12,13 2,6" />
                  </svg>
                  <span>info@kartajet.tn</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-gray-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mt-0.5 flex-shrink-0 text-[#FFD700]"
                  >
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                  <span>Kartajet Headquarters, Tunis, Tunisia</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-10 border-t border-gray-800 pt-6">
            <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
              <div className="flex flex-wrap gap-4">
                <Link href="#" className="text-xs text-gray-400 hover:text-[#FFD700]">
                  Terms & Conditions
                </Link>
                <Link href="#" className="text-xs text-gray-400 hover:text-[#FFD700]">
                  Privacy Policy
                </Link>
                <Link href="#" className="text-xs text-gray-400 hover:text-[#FFD700]">
                  Cookie Policy
                </Link>
                <Link href="#" className="text-xs text-gray-400 hover:text-[#FFD700]">
                  Accessibility
                </Link>
              </div>
              <div className="text-xs text-gray-400">© {new Date().getFullYear()} Kartajet. All rights reserved.</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
