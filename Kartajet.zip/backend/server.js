const express = require("express")
const cors = require("cors")
const morgan = require("morgan")

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())
app.use(morgan("dev"))

// Sample data
const services = [
  {
    id: 1,
    title: "Premium Internet",
    description: "Ultra-fast fiber internet with unlimited data and priority support.",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 2,
    title: "Elite Mobile Plans",
    description: "Exclusive mobile plans with unlimited calls, data, and international roaming.",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 3,
    title: "Business Solutions",
    description: "Tailored telecommunications solutions for businesses of all sizes.",
    image: "/placeholder.svg?height=200&width=400",
  },
]

const promos = [
  {
    id: 1,
    title: "Premium Offer 1",
    description: "Exclusive benefits and premium services at special rates.",
    image: "/placeholder.svg?height=200&width=400&text=Promo+1",
    tag: "Limited Time",
  },
  {
    id: 2,
    title: "Premium Offer 2",
    description: "Exclusive benefits and premium services at special rates.",
    image: "/placeholder.svg?height=200&width=400&text=Promo+2",
    tag: "Limited Time",
  },
  {
    id: 3,
    title: "Premium Offer 3",
    description: "Exclusive benefits and premium services at special rates.",
    image: "/placeholder.svg?height=200&width=400&text=Promo+3",
    tag: "Limited Time",
  },
]

// Routes
app.get("/api/services", (req, res) => {
  res.json(services)
})

app.get("/api/promos", (req, res) => {
  res.json(promos)
})

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Kartajet API is running" })
})

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
