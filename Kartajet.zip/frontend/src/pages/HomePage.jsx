"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import HeroSection from "../components/HeroSection"
import QuickActions from "../components/QuickActions"
import ServicesSection from "../components/ServicesSection"
import PromosSection from "../components/PromosSection"
import AppDownload from "../components/AppDownload"
import TestimonialsSection from "../components/TestimonialsSection"

function HomePage() {
  const [services, setServices] = useState([])
  const [promos, setPromos] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [servicesRes, promosRes] = await Promise.all([
          axios.get("http://localhost:5000/api/services"),
          axios.get("http://localhost:5000/api/promos"),
        ])

        setServices(servicesRes.data)
        setPromos(promosRes.data)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching data:", error)
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  return (
    <main>
      <HeroSection />
      <QuickActions />
      <ServicesSection services={services} loading={loading} />
      <PromosSection promos={promos} loading={loading} />
      <AppDownload />
      <TestimonialsSection />
    </main>
  )
}

export default HomePage
