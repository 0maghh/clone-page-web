"use client"

import { useState } from "react"

function PromosSection({ promos, loading }) {
  const [currentSlide, setCurrentSlide] = useState(0)

  // Fallback data if API fails or is loading
  const fallbackPromos = [
    {
      id: 1,
      title: "Premium Offer 1",
      description: "Exclusive benefits and premium services at special rates.",
      image: "/placeholder.svg?height=200&width=400&text=Promo+1",
      tag: "Limited Time",
    },
    {
      id: 2,
      title: "Premium Offer 2",
      description: "Exclusive benefits and premium services at special rates.",
      image: "/placeholder.svg?height=200&width=400&text=Promo+2",
      tag: "Limited Time",
    },
    {
      id: 3,
      title: "Premium Offer 3",
      description: "Exclusive benefits and premium services at special rates.",
      image: "/placeholder.svg?height=200&width=400&text=Promo+3",
      tag: "Limited Time",
    },
  ]

  const displayPromos = promos.length > 0 ? promos : fallbackPromos

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % displayPromos.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + displayPromos.length) % displayPromos.length)
  }

  return (
    <section className="py-12">
      <div className="container">
        <div className="mb-10 text-center">
          <h2 className="font-serif text-3xl font-bold tracking-tight text-text md:text-4xl">Exclusive Offers</h2>
          <p className="mt-2 text-text/70">Limited-time promotions and special deals</p>
        </div>

        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {displayPromos.map((promo) => (
                <div key={promo.id} className="min-w-full px-4 md:min-w-[50%] lg:min-w-[33.333%]">
                  <div className="overflow-hidden rounded-lg bg-white p-1 shadow-md">
                    <div className="overflow-hidden rounded-lg">
                      <img
                        src={promo.image || "/placeholder.svg"}
                        alt={promo.title}
                        className="h-48 w-full object-cover transition-transform duration-300 hover:scale-105"
                      />
                    </div>
                    <div className="p-6">
                      <div className="mb-2 inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                        {promo.tag}
                      </div>
                      <h3 className="mb-2 font-serif text-lg font-semibold">{promo.title}</h3>
                      <p className="mb-4 text-sm text-text/70">{promo.description}</p>
                      <button className="w-full rounded-md bg-secondary px-4 py-2 text-sm font-medium text-text hover:bg-secondary/90">
                        Get Now
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 flex justify-center gap-2">
            <button
              onClick={prevSlide}
              className="flex h-8 w-8 items-center justify-center rounded-full border border-primary text-primary transition-colors hover:bg-primary hover:text-white"
              aria-label="Previous slide"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m15 18-6-6 6-6" />
              </svg>
            </button>
            <button
              onClick={nextSlide}
              className="flex h-8 w-8 items-center justify-center rounded-full border border-primary text-primary transition-colors hover:bg-primary hover:text-white"
              aria-label="Next slide"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m9 18 6-6-6-6" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default PromosSection
