function TestimonialsSection() {
  const testimonials = [
    {
      id: 1,
      text: "Kartajet provides exceptional service with lightning-fast internet and reliable connectivity. Their customer support is outstanding.",
      name: "Client Name",
      role: "Premium Customer",
    },
    {
      id: 2,
      text: "I've been using Kartajet for my business needs for over a year now. Their business solutions are tailored perfectly to our requirements.",
      name: "Business Owner",
      role: "Enterprise Client",
    },
    {
      id: 3,
      text: "The mobile plans offered by Kartajet are unmatched in value. I get great coverage and amazing data speeds wherever I go.",
      name: "Satisfied User",
      role: "Mobile Customer",
    },
  ]

  return (
    <section className="py-12">
      <div className="container">
        <div className="mb-10 text-center">
          <h2 className="font-serif text-3xl font-bold tracking-tight text-text md:text-4xl">What Our Clients Say</h2>
          <p className="mt-2 text-text/70">Hear from our satisfied customers</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="rounded-lg border border-primary/10 bg-white p-6 shadow-md">
              <div className="mb-4 flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="#FFD700"
                    stroke="#FFD700"
                    strokeWidth="1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                ))}
              </div>
              <p className="mb-4 italic text-text/70">"{testimonial.text}"</p>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/20"></div>
                <div>
                  <h4 className="font-medium">{testimonial.name}</h4>
                  <p className="text-xs text-text/70">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default TestimonialsSection
