function ServicesSection({ services, loading }) {
  // Fallback data if API fails or is loading
  const fallbackServices = [
    {
      id: 1,
      title: "Premium Internet",
      description: "Ultra-fast fiber internet with unlimited data and priority support.",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      title: "Elite Mobile Plans",
      description: "Exclusive mobile plans with unlimited calls, data, and international roaming.",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      title: "Business Solutions",
      description: "Tailored telecommunications solutions for businesses of all sizes.",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  const displayServices = services.length > 0 ? services : fallbackServices

  return (
    <section className="bg-white py-12">
      <div className="container">
        <div className="mb-10 text-center">
          <h2 className="font-serif text-3xl font-bold tracking-tight text-text md:text-4xl">Premium Services</h2>
          <p className="mt-2 text-text/70">Discover our range of exclusive services designed for your needs</p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {displayServices.map((service) => (
            <div
              key={service.id}
              className="group overflow-hidden rounded-lg border border-primary/10 bg-background shadow-sm transition-all hover:shadow-md"
            >
              <div className="relative h-48 w-full overflow-hidden">
                <img
                  src={service.image || "/placeholder.svg"}
                  alt={service.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-text/70 to-transparent"></div>
                <div className="absolute bottom-4 left-4">
                  <h3 className="font-serif text-xl font-bold text-white">{service.title}</h3>
                </div>
              </div>
              <div className="p-6">
                <p className="mb-4 text-sm text-text/70">{service.description}</p>
                <button className="w-full rounded-md border border-primary bg-transparent px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary hover:text-white">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default ServicesSection
