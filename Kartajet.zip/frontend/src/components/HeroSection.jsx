function HeroSection() {
  return (
    <section className="relative">
      <div className="relative h-[400px] w-full md:h-[600px] lg:h-[700px]">
        <img
          src="/images/kartajet-hero.png"
          alt="Kartajet 5G - Tunisia rises, Tunisia is stronger"
          className="h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-dark/40 to-transparent">
          <div className="container relative h-full">
            {/* CTA Button positioned at bottom right */}
            <div className="absolute bottom-8 right-4 md:bottom-12 md:right-8">
              <button className="rounded-md border border-secondary/20 bg-secondary px-6 py-6 text-base font-serif tracking-wide text-dark shadow-lg transition-all duration-300 hover:scale-105 hover:bg-secondary/90 md:py-7 md:text-lg">
                Découvrez Kartajet
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default HeroSection
