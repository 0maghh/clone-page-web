"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import { Globe, Menu, Search, ShoppingCart, User } from "lucide-react"

function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      {/* Top Bar */}
      <div className="hidden border-b border-primary/20 bg-background py-1 md:block">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="#" className="text-xs text-text hover:text-primary">
              Kartajet Business
            </Link>
            <Link to="#" className="text-xs text-text hover:text-primary">
              About Us
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Globe className="h-3 w-3 text-primary" />
              <span className="text-xs">FR</span>
            </div>
            <Link to="#" className="text-xs text-text hover:text-primary">
              Careers
            </Link>
            <Link to="#" className="text-xs text-text hover:text-primary">
              Contact Us
            </Link>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header className="sticky top-0 z-50 border-b border-primary/20 bg-background">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <button className="text-primary md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              <Menu className="h-6 w-6" />
            </button>
            <Link to="/" className="flex items-center gap-2">
              <div className="relative h-10 w-32 overflow-hidden rounded bg-dark">
                <img src="/images/kartajet-logo.png" alt="Kartajet Logo" className="h-full w-full object-contain" />
              </div>
            </Link>
          </div>

          <nav className="hidden md:flex md:items-center md:gap-6">
            <Link to="#" className="text-sm font-medium text-text hover:text-primary">
              Services
            </Link>
            <Link to="#" className="text-sm font-medium text-text hover:text-primary">
              Support
            </Link>
            <Link to="#" className="text-sm font-medium text-text hover:text-primary">
              For Businesses
            </Link>
            <Link to="#" className="text-sm font-medium text-text hover:text-primary">
              Offers
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <button className="text-primary">
              <Search className="h-5 w-5" />
            </button>
            <button className="text-primary">
              <ShoppingCart className="h-5 w-5" />
            </button>
            <button className="hidden items-center gap-2 rounded-md border border-primary px-3 py-2 text-sm font-medium text-primary hover:bg-primary hover:text-white md:flex">
              <User className="h-4 w-4" />
              <span>Login</span>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="container py-4 md:hidden">
            <nav className="flex flex-col space-y-4">
              <Link to="#" className="text-sm font-medium text-text hover:text-primary">
                Services
              </Link>
              <Link to="#" className="text-sm font-medium text-text hover:text-primary">
                Support
              </Link>
              <Link to="#" className="text-sm font-medium text-text hover:text-primary">
                For Businesses
              </Link>
              <Link to="#" className="text-sm font-medium text-text hover:text-primary">
                Offers
              </Link>
              <button className="flex w-full items-center justify-center gap-2 rounded-md border border-primary px-3 py-2 text-sm font-medium text-primary hover:bg-primary hover:text-white">
                <User className="h-4 w-4" />
                <span>Login</span>
              </button>
            </nav>
          </div>
        )}
      </header>
    </>
  )
}

export default Navbar
