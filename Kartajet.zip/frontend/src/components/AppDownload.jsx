function AppDownload() {
  return (
    <section className="bg-white py-12">
      <div className="container">
        <div className="overflow-hidden rounded-xl bg-gradient-to-r from-primary to-[#8A2BE2]">
          <div className="grid items-center gap-8 md:grid-cols-2">
            <div className="p-8 text-white">
              <h2 className="mb-4 font-serif text-3xl font-bold tracking-tight md:text-4xl">
                Download the Kartajet App
              </h2>
              <p className="mb-6">
                Manage your account, pay bills, recharge, and enjoy exclusive offers all in one place.
              </p>
              <div className="flex flex-wrap gap-4">
                <img
                  src="/placeholder.svg?height=50&width=150&text=App+Store"
                  alt="App Store"
                  className="h-12 w-auto"
                />
                <img
                  src="/placeholder.svg?height=50&width=150&text=Google+Play"
                  alt="Google Play"
                  className="h-12 w-auto"
                />
              </div>
            </div>
            <div className="flex justify-center p-4">
              <div className="relative h-[300px] w-[200px] md:h-[400px] md:w-[250px]">
                <img
                  src="/placeholder.svg?height=400&width=250&text=App+Screenshot"
                  alt="Kartajet App"
                  className="h-full w-full object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default AppDownload
