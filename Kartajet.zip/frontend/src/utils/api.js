import axios from "axios"

const API_URL = "http://localhost:5000/api"

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
})

export const getServices = async () => {
  try {
    const response = await api.get("/services")
    return response.data
  } catch (error) {
    console.error("Error fetching services:", error)
    return []
  }
}

export const getPromos = async () => {
  try {
    const response = await api.get("/promos")
    return response.data
  } catch (error) {
    console.error("Error fetching promos:", error)
    return []
  }
}
